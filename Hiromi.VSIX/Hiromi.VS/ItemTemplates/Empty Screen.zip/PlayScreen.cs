﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Hiromi;
using Microsoft.Xna.Framework;

namespace $rootnamespace$
{
    class $safeitemname$ : Screen
    {
        public $safeitemname$()
        {
            this.BackgroundColor = Color.CornflowerBlue;
        }
    }
}
