﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Hiromi;
using Microsoft.Xna.Framework;

namespace $safeprojectname$.Screens
{
    class PlayScreen : Screen
    {
        public PlayScreen()
        {
            this.BackgroundColor = Color.CornflowerBlue;
        }
    }
}
